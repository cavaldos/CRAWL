

To create a new miner, extend the `Miner` class by implementing all the required functions.
Finally, add the new miner to the list of the `__init__.py` file located in the `Miner folder`.