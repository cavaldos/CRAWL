class InvalidData(Exception):
    pass